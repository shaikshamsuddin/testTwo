export default function TableContent(props: any): JSX.Element;
//# sourceMappingURL=tableTabOne.d.ts.map