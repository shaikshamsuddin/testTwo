declare interface IListItemsHooksWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'ListItemsHooksWebPartStrings' {
  const strings: IListItemsHooksWebPartStrings;
  export = strings;
}
