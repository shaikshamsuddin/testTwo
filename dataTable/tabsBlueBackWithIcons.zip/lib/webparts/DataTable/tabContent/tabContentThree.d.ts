export default function DenseTable(): JSX.Element;
//# sourceMappingURL=tabContentThree.d.ts.map