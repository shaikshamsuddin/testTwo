export default function CollapsibleTable(): JSX.Element;
//# sourceMappingURL=tabContentTwo.d.ts.map