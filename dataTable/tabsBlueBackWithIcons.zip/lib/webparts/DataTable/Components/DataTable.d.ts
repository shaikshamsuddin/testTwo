export default function StylishTabs(props: any): JSX.Element;
//# sourceMappingURL=DataTable.d.ts.map