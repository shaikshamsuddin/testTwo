interface Props {
    data: any;
    columns: any;
    index: number;
    isExpandAllEnabled: boolean;
}
declare function GroupData(props: Props): JSX.Element;
export default GroupData;
//# sourceMappingURL=GroupData.d.ts.map