export default function FaqComponent(props: any): JSX.Element;
//# sourceMappingURL=FaqComponent.d.ts.map