declare const styles: {
    faqComponent: string;
    minusIconBlock: string;
    accordionBlock: string;
    accordionTextStyle: string;
    minusIconStyle: string;
    plusIconBlock: string;
    plusIconStyle: string;
    contentListStyled: string;
};
export default styles;
//# sourceMappingURL=FaqComponent.module.scss.d.ts.map