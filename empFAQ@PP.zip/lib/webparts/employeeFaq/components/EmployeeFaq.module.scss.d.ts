declare const styles: {
    employeeFaq: string;
    mainHeading: string;
};
export default styles;
//# sourceMappingURL=EmployeeFaq.module.scss.d.ts.map