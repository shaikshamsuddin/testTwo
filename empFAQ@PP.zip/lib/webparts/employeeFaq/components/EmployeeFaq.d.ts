import * as React from 'react';
import { IEmployeeFaqProps } from './IEmployeeFaqProps';
export default class EmployeeFaq extends React.Component<IEmployeeFaqProps, any> {
    constructor(props: any);
    componentDidMount(): void;
    render(): React.ReactElement<IEmployeeFaqProps>;
}
//# sourceMappingURL=EmployeeFaq.d.ts.map