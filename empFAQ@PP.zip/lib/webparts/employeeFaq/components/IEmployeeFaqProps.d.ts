import { WebPartContext } from "@microsoft/sp-webpart-base";
export interface IEmployeeFaqProps {
    description: string;
    HeaderLabel: string;
    keyLabel: string;
    context: WebPartContext;
    color: string;
}
//# sourceMappingURL=IEmployeeFaqProps.d.ts.map