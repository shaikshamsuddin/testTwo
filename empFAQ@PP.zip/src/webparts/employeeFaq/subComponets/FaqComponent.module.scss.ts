/* tslint:disable */
require("./FaqComponent.module.css");
const styles = {
  faqComponent: 'faqComponent_7380c30a',
  minusIconBlock: 'minusIconBlock_7380c30a',
  accordionBlock: 'accordionBlock_7380c30a',
  accordionTextStyle: 'accordionTextStyle_7380c30a',
  minusIconStyle: 'minusIconStyle_7380c30a',
  plusIconBlock: 'plusIconBlock_7380c30a',
  plusIconStyle: 'plusIconStyle_7380c30a',
  contentListStyled: 'contentListStyled_7380c30a'
};

export default styles;
/* tslint:enable */