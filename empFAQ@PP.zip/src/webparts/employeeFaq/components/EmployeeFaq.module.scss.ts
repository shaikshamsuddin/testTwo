/* tslint:disable */
require("./EmployeeFaq.module.css");
const styles = {
  employeeFaq: 'employeeFaq_3f447c1a',
  mainHeading: 'mainHeading_3f447c1a'
};

export default styles;
/* tslint:enable */