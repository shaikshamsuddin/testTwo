declare interface IEmployeeFaqWebPartStrings {
  ColorLabel: any;
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'EmployeeFaqWebPartStrings' {
  const strings: IEmployeeFaqWebPartStrings;
  export = strings;
}
