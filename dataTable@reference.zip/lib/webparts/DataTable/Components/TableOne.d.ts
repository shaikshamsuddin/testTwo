export default function GroupByTable(): JSX.Element;
//# sourceMappingURL=TableOne.d.ts.map