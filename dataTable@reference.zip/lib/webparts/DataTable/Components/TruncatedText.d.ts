interface Props {
    text: string;
}
declare function TruncatedText({ text }: Props): JSX.Element;
export default TruncatedText;
//# sourceMappingURL=TruncatedText.d.ts.map