import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { IFilePickerResult } from "@pnp/spfx-property-controls/lib/PropertyFieldFilePicker";
export interface IHooksDemoWebPartProps {
    description: string;
    filePickerResult: IFilePickerResult;
    headerText: string;
    numberOfLines: number;
}
export default class HooksDemoWebPart extends BaseClientSideWebPart<IHooksDemoWebPartProps> {
    render(): void;
    protected onDispose(): void;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=HooksDemoWebPart.d.ts.map