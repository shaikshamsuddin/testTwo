import * as React from "react";
import { IHooksDemoProps } from "./IHooksDemoProps";
export default class ImageUrl extends React.Component<IHooksDemoProps, any> {
    constructor(props: IHooksDemoProps);
    private saveIntoSharePoint;
}
//# sourceMappingURL=Upload.d.ts.map