import "./style.css";
declare function Main(props: any): JSX.Element;
export default Main;
//# sourceMappingURL=HooksDemoFC.d.ts.map