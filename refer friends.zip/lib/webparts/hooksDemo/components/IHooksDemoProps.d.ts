import { WebPartContext } from "@microsoft/sp-webpart-base";
export interface IHooksDemoProps {
    description: string;
    context: WebPartContext;
}
//# sourceMappingURL=IHooksDemoProps.d.ts.map