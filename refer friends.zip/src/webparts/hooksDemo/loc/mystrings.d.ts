declare interface IHooksDemoWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'HooksDemoWebPartStrings' {
  const strings: IHooksDemoWebPartStrings;
  export = strings;
}
