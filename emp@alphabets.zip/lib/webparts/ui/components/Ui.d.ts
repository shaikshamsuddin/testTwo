import * as React from 'react';
import { IUiProps } from './IUiProps';
export default class Ui extends React.Component<IUiProps, any> {
    constructor(props: IUiProps);
    private disable;
    private enable;
    private filterAlphabets;
    render(): React.ReactElement<IUiProps>;
}
//# sourceMappingURL=Ui.d.ts.map