declare const styles: {
    ui: string;
    ribbon: string;
    txt: string;
    btnGroup: string;
    button: string;
    card: string;
    profile: string;
    title: string;
    company: string;
    name: string;
    phone: string;
    mailId: string;
    detailsiconPhone: string;
    detailsicon: string;
    trail: string;
    tableBody: string;
};
export default styles;
//# sourceMappingURL=Ui.module.scss.d.ts.map