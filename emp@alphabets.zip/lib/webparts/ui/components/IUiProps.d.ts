export interface IUiProps {
    description: string;
}
//# sourceMappingURL=IUiProps.d.ts.map