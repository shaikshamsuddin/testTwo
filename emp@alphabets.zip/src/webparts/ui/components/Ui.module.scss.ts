/* tslint:disable */
require("./Ui.module.css");
const styles = {
  ui: 'ui_df313171',
  ribbon: 'ribbon_df313171',
  txt: 'txt_df313171',
  btnGroup: 'btnGroup_df313171',
  button: 'button_df313171',
  card: 'card_df313171',
  profile: 'profile_df313171',
  title: 'title_df313171',
  company: 'company_df313171',
  name: 'name_df313171',
  phone: 'phone_df313171',
  mailId: 'mailId_df313171',
  detailsiconPhone: 'detailsiconPhone_df313171',
  detailsicon: 'detailsicon_df313171',
  trail: 'trail_df313171',
  tableBody: 'tableBody_df313171'
};

export default styles;
/* tslint:enable */