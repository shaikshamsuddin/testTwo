export interface IUiProps {
  description: string;
}
