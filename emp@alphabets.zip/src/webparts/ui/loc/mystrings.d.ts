declare interface IUiWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'UiWebPartStrings' {
  const strings: IUiWebPartStrings;
  export = strings;
}
