/* tslint:disable */
require("./ContentAndImageSlider.module.css");
const styles = {
  contentAndImageSlider: 'contentAndImageSlider_b90d832a',
  containerBlock: 'containerBlock_b90d832a',
  leftContentBlock: 'leftContentBlock_b90d832a',
  leftContentHeading: 'leftContentHeading_b90d832a',
  leftContentSecondHeading: 'leftContentSecondHeading_b90d832a',
  mainTextContentBox: 'mainTextContentBox_b90d832a',
  coloredChipText: 'coloredChipText_b90d832a',
  iconFlexEndBox: 'iconFlexEndBox_b90d832a',
  leftArrowContentIcon: 'leftArrowContentIcon_b90d832a',
  rightArrowContentIcon: 'rightArrowContentIcon_b90d832a',
  rightContentImage: 'rightContentImage_b90d832a'
};

export default styles;
/* tslint:enable */