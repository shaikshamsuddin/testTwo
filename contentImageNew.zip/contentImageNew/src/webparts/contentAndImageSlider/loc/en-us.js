define([], function() {
  return {
    "PropertyPaneDescription": "Customize the Webpart Here",
    "BasicGroupName": "Group Name",
    "DescriptionFieldLabel": "Description Field",
    "ColorLabel":"Select Color"
  }
});