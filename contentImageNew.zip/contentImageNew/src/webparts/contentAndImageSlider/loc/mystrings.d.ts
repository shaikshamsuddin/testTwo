declare interface IContentAndImageSliderWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
  ColorLabel:string;
}

declare module 'ContentAndImageSliderWebPartStrings' {
  const strings: IContentAndImageSliderWebPartStrings;
  export = strings;
}
