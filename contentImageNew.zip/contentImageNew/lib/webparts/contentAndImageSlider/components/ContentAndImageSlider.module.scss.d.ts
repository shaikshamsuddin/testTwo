declare const styles: {
    contentAndImageSlider: string;
    containerBlock: string;
    leftContentBlock: string;
    leftContentHeading: string;
    leftContentSecondHeading: string;
    mainTextContentBox: string;
    coloredChipText: string;
    iconFlexEndBox: string;
    leftArrowContentIcon: string;
    rightArrowContentIcon: string;
    rightContentImage: string;
};
export default styles;
//# sourceMappingURL=ContentAndImageSlider.module.scss.d.ts.map