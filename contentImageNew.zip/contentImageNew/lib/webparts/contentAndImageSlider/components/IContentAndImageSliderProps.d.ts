import { WebPartContext } from '@microsoft/sp-webpart-base';
export interface IContentAndImageSliderProps {
    description: string;
    context: WebPartContext;
    color: string;
}
//# sourceMappingURL=IContentAndImageSliderProps.d.ts.map