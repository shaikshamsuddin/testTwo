import * as React from "react";
import { IContentAndImageSliderProps } from "./IContentAndImageSliderProps";
export default class ContentAndImageSlider extends React.Component<IContentAndImageSliderProps, any> {
    constructor(props: IContentAndImageSliderProps);
    handleNext: () => void;
    handleBack: () => void;
    componentDidMount(): Promise<void>;
    render(): React.ReactElement<IContentAndImageSliderProps>;
}
//# sourceMappingURL=ContentAndImageSlider.d.ts.map