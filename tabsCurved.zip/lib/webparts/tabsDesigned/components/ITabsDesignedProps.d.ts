export interface ITabsDesignedProps {
    description: string;
}
//# sourceMappingURL=ITabsDesignedProps.d.ts.map