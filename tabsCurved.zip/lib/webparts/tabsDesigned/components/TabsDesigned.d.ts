import * as React from 'react';
import { ITabsDesignedProps } from './ITabsDesignedProps';
export default class TabsDesigned extends React.Component<ITabsDesignedProps, {}> {
    render(): React.ReactElement<ITabsDesignedProps>;
}
//# sourceMappingURL=TabsDesigned.d.ts.map