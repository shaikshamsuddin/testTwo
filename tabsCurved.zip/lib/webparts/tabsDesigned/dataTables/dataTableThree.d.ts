export default function EnhancedTable(): JSX.Element;
//# sourceMappingURL=dataTableThree.d.ts.map