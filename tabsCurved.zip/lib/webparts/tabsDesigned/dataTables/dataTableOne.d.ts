export default function CustomizedTables(): JSX.Element;
//# sourceMappingURL=dataTableOne.d.ts.map