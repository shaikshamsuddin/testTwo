export default function CustomPaginationActionsTable(): JSX.Element;
//# sourceMappingURL=dataTableTwo.d.ts.map