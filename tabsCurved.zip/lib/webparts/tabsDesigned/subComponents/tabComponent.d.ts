export default function TabComponent(): JSX.Element;
//# sourceMappingURL=tabComponent.d.ts.map