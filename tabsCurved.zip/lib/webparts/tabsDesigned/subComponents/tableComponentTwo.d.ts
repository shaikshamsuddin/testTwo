export default function CustomPaginationActionsTable(): JSX.Element;
//# sourceMappingURL=tableComponentTwo.d.ts.map