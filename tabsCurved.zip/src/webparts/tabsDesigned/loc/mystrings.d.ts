declare interface ITabsDesignedWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'TabsDesignedWebPartStrings' {
  const strings: ITabsDesignedWebPartStrings;
  export = strings;
}
