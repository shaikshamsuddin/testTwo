/* tslint:disable */
require("./TabsDesigned.module.css");
const styles = {
  tabsDesigned: 'tabsDesigned_25232150',
  container: 'container_25232150',
  row: 'row_25232150',
  column: 'column_25232150',
  'ms-Grid': 'ms-Grid_25232150',
  title: 'title_25232150',
  subTitle: 'subTitle_25232150',
  description: 'description_25232150',
  button: 'button_25232150',
  label: 'label_25232150'
};

export default styles;
/* tslint:enable */