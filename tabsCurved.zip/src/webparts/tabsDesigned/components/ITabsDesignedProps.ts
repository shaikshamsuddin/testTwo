export interface ITabsDesignedProps {
  description: string;
}
